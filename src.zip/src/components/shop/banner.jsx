import React from "react";
import banner from '../../assets/banner.png'
import '../../styles/b.css'

const Banner = () =>{
    return <img className='banner' src={banner}/>
}

export default Banner